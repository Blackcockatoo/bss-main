# MetaPet Landing Page Strategy

## Design Philosophy
**Modern Minimalism with Depth**: Clean, spacious layout with strategic use of color, typography, and subtle animations. Focus on clarity and user guidance without overwhelming visual noise.

## Color Palette
- **Primary**: Deep Slate (Navy) - Trust, stability
- **Accent**: Cyan/Teal - Energy, innovation, growth
- **Secondary**: Soft Purple - Creativity, learning
- **Neutral**: Grays and whites for readability
- **Text**: Dark slate on light backgrounds, light on dark

## Typography
- **Display**: Bold, geometric sans-serif (Poppins Bold) for headlines
- **Body**: Clean, readable sans-serif (Poppins Regular) for content
- **Accent**: Monospace for technical elements

## Layout Structure

### 1. Hero Section
- Clear value proposition
- Single CTA button
- Subtle animated background or gradient
- No overwhelming imagery

### 2. Three User Paths
- **For Students**: Explore, learn, grow
- **For Teachers**: Manage, assess, guide
- **For Developers**: Build, integrate, extend

### 3. Feature Highlights (Consolidated)
- Identity & Genome System
- Evolution & Growth
- Classroom Integration
- Breeding & Genetics
- Wellness Tracking

### 4. How It Works
- Step-by-step visual guide
- Clear progression
- Minimal text

### 5. Call to Action
- Primary: Start Exploring
- Secondary: Learn More
- Tertiary: View Documentation

## Content Deduplication Strategy

### Eliminate Redundancy
- Remove duplicate feature descriptions
- Consolidate "Classroom Modes" and "Learning Modes"
- Merge "Breeding Lab" and "Genetics" sections
- Unify "Wellness" and "Vitals" terminology

### Establish Clear Hierarchy
- Hero → Value Prop
- User Paths → Role-specific benefits
- Features → Consolidated, non-duplicated list
- CTA → Single, clear next step

## Navigation
- Simple top nav with: Home, Features, Docs, Start
- Mobile-friendly hamburger menu
- Clear escape routes from all pages
- Breadcrumb navigation on subpages

## Responsive Design
- Mobile-first approach
- Touch-friendly buttons (min 48px)
- Readable text at all sizes
- Optimized images for all devices
