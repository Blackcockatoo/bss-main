import { Button } from "@/components/ui/button";
import { ArrowRight, Zap, Users, Code, Sparkles, Heart, Brain, Dna } from "lucide-react";
import { useState } from "react";

export default function Home() {
  const [activeTab, setActiveTab] = useState<"students" | "teachers" | "developers">("students");

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-slate-100">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="font-bold text-lg text-slate-900">MetaPet</span>
          </div>
          <div className="hidden md:flex items-center gap-8">
            <a href="#features" className="text-sm text-slate-600 hover:text-slate-900 transition">Features</a>
            <a href="#how-it-works" className="text-sm text-slate-600 hover:text-slate-900 transition">How It Works</a>
            <a href="#paths" className="text-sm text-slate-600 hover:text-slate-900 transition">For You</a>
            <Button size="sm" className="bg-cyan-600 hover:bg-cyan-700 text-white">Get Started</Button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 md:py-32">
        <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 via-transparent to-purple-500/10" />
        <div className="container relative z-10">
          <div className="max-w-3xl mx-auto text-center space-y-8">
            <h1 className="text-5xl md:text-6xl font-bold text-slate-900 leading-tight">
              Your Digital Companion<br />
              <span className="bg-gradient-to-r from-cyan-600 to-blue-600 bg-clip-text text-transparent">Grows With You</span>
            </h1>
            <p className="text-xl text-slate-600 max-w-2xl mx-auto">
              MetaPet is an interactive learning platform where you create, nurture, and evolve a unique digital pet. Explore genetics, build habits, and grow together through play, learning, and discovery.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
              <Button size="lg" className="bg-cyan-600 hover:bg-cyan-700 text-white gap-2">
                Start Exploring <ArrowRight className="w-4 h-4" />
              </Button>
              <Button size="lg" variant="outline" className="border-slate-300 text-slate-900">
                Learn More
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* User Paths Section */}
      <section id="paths" className="py-20 bg-white">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-slate-900 mb-4">Choose Your Path</h2>
            <p className="text-lg text-slate-600">MetaPet adapts to your role and goals</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Students Path */}
            <div 
              onClick={() => setActiveTab("students")}
              className={`p-8 rounded-2xl cursor-pointer transition-all ${
                activeTab === "students"
                  ? "bg-cyan-50 border-2 border-cyan-500 shadow-lg"
                  : "bg-slate-50 border-2 border-slate-200 hover:border-cyan-300"
              }`}
            >
              <div className="w-12 h-12 rounded-xl bg-cyan-100 flex items-center justify-center mb-4">
                <Brain className="w-6 h-6 text-cyan-600" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-3">For Students</h3>
              <p className="text-slate-600 mb-6">
                Create your pet, explore its unique traits, and discover how genetics shape behavior. Learn through interactive play and reflection.
              </p>
              <ul className="space-y-2 text-sm text-slate-600">
                <li className="flex items-start gap-2">
                  <span className="text-cyan-600 font-bold mt-1">•</span>
                  <span>Mint your unique digital companion</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-cyan-600 font-bold mt-1">•</span>
                  <span>Nurture and evolve through interaction</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-cyan-600 font-bold mt-1">•</span>
                  <span>Explore genome and trait systems</span>
                </li>
              </ul>
            </div>

            {/* Teachers Path */}
            <div 
              onClick={() => setActiveTab("teachers")}
              className={`p-8 rounded-2xl cursor-pointer transition-all ${
                activeTab === "teachers"
                  ? "bg-purple-50 border-2 border-purple-500 shadow-lg"
                  : "bg-slate-50 border-2 border-slate-200 hover:border-purple-300"
              }`}
            >
              <div className="w-12 h-12 rounded-xl bg-purple-100 flex items-center justify-center mb-4">
                <Users className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-3">For Teachers</h3>
              <p className="text-slate-600 mb-6">
                Manage classrooms, track student progress, and deliver standards-aligned lessons through engaging, interactive activities.
              </p>
              <ul className="space-y-2 text-sm text-slate-600">
                <li className="flex items-start gap-2">
                  <span className="text-purple-600 font-bold mt-1">•</span>
                  <span>Build and manage student rosters</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-600 font-bold mt-1">•</span>
                  <span>Create and assign lessons</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-600 font-bold mt-1">•</span>
                  <span>Track progress and export findings</span>
                </li>
              </ul>
            </div>

            {/* Developers Path */}
            <div 
              onClick={() => setActiveTab("developers")}
              className={`p-8 rounded-2xl cursor-pointer transition-all ${
                activeTab === "developers"
                  ? "bg-blue-50 border-2 border-blue-500 shadow-lg"
                  : "bg-slate-50 border-2 border-slate-200 hover:border-blue-300"
              }`}
            >
              <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center mb-4">
                <Code className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-2xl font-bold text-slate-900 mb-3">For Developers</h3>
              <p className="text-slate-600 mb-6">
                Build on top of MetaPet's open architecture. Integrate custom addons, extend functionality, and create new experiences.
              </p>
              <ul className="space-y-2 text-sm text-slate-600">
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 font-bold mt-1">•</span>
                  <span>Access genome and identity APIs</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 font-bold mt-1">•</span>
                  <span>Create and sign custom addons</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 font-bold mt-1">•</span>
                  <span>Build on open-source foundation</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-slate-50">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-slate-900 mb-4">Core Features</h2>
            <p className="text-lg text-slate-600">Everything you need to create, nurture, and evolve</p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Feature Cards */}
            {[
              {
                icon: Dna,
                title: "Unique Identity",
                description: "Each pet has a cryptographically secure identity with unique genome and traits derived from DNA hashing."
              },
              {
                icon: Sparkles,
                title: "Evolution System",
                description: "Watch your pet evolve through stages as you interact, nurture, and help it grow over time."
              },
              {
                icon: Heart,
                title: "Vitals & Wellness",
                description: "Track hunger, hygiene, mood, and energy. Balance care with learning for optimal growth."
              },
              {
                icon: Brain,
                title: "Genome Explorer",
                description: "Dive deep into the science of genetics. Understand how traits emerge from DNA sequences."
              },
              {
                icon: Users,
                title: "Classroom Ready",
                description: "Designed for education. Manage students, track progress, and deliver standards-aligned lessons."
              },
              {
                icon: Zap,
                title: "Breeding & Genetics",
                description: "Breed pets to explore inheritance patterns. Discover mutations and create unique lineages."
              }
            ].map((feature, idx) => {
              const Icon = feature.icon;
              return (
                <div key={idx} className="bg-white p-8 rounded-xl border border-slate-200 hover:border-cyan-300 transition">
                  <div className="w-12 h-12 rounded-lg bg-cyan-100 flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-cyan-600" />
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-2">{feature.title}</h3>
                  <p className="text-slate-600">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-20 bg-white">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-slate-900 mb-4">How It Works</h2>
            <p className="text-lg text-slate-600">Get started in three simple steps</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: "1",
                title: "Create Your Pet",
                description: "Mint a unique digital companion. Your pet's genome is generated cryptographically and stored securely."
              },
              {
                step: "2",
                title: "Nurture & Interact",
                description: "Feed, play, and care for your pet. Every interaction shapes its personality and traits."
              },
              {
                step: "3",
                title: "Explore & Grow",
                description: "Discover genome patterns, breed with others, and watch your pet evolve through distinct stages."
              }
            ].map((item, idx) => (
              <div key={idx} className="relative">
                <div className="flex flex-col items-center text-center">
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center text-white text-2xl font-bold mb-4">
                    {item.step}
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-2">{item.title}</h3>
                  <p className="text-slate-600">{item.description}</p>
                </div>
                {idx < 2 && (
                  <div className="hidden md:block absolute top-8 -right-4 w-8 h-0.5 bg-gradient-to-r from-cyan-500 to-transparent" />
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-cyan-600 to-blue-600">
        <div className="container text-center">
          <h2 className="text-4xl font-bold text-white mb-4">Ready to Begin?</h2>
          <p className="text-xl text-cyan-100 mb-8 max-w-2xl mx-auto">
            Start your MetaPet journey today. Create, nurture, and evolve your unique digital companion.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button size="lg" className="bg-white text-cyan-600 hover:bg-cyan-50 gap-2">
              Start Exploring <ArrowRight className="w-4 h-4" />
            </Button>
            <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
              View Documentation
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-slate-900 text-slate-400 py-12">
        <div className="container">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div>
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center">
                  <Sparkles className="w-5 h-5 text-white" />
                </div>
                <span className="font-bold text-white">MetaPet</span>
              </div>
              <p className="text-sm">Your digital companion grows with you.</p>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Product</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition">Features</a></li>
                <li><a href="#" className="hover:text-white transition">Pricing</a></li>
                <li><a href="#" className="hover:text-white transition">Security</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Resources</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition">Documentation</a></li>
                <li><a href="#" className="hover:text-white transition">API Reference</a></li>
                <li><a href="#" className="hover:text-white transition">Community</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-white mb-4">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li><a href="#" className="hover:text-white transition">Privacy</a></li>
                <li><a href="#" className="hover:text-white transition">Terms</a></li>
                <li><a href="#" className="hover:text-white transition">Contact</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-slate-800 pt-8 text-center text-sm">
            <p>&copy; 2026 MetaPet. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
